document.getElementById('contact-form').addEventListener('submit', function(event) {
    event.preventDefault();

    // Getting the values from the form fields
    const name = event.target.name.value;
    const email = event.target.email.value;
    const message = event.target.message.value;

    // Simple form validation
    if (name === "" || email === "" || message === "") {
        alert("Please fill in all fields.");
        return;
    }

    // Display a thank you message
    alert('Thank you for contacting me, ' + name + '! I will get back to you soon.');

    // Reset the form after submission
    event.target.reset();
});
