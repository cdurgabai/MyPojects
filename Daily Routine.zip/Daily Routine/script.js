// DOM Elements
const taskInput = document.getElementById('task-input');
const timeSelect = document.getElementById('time-select');
const addBtn = document.getElementById('add-btn');
const currentTime = document.getElementById('current-time');
const currentDate = document.getElementById('current-date');
const progressFill = document.getElementById('progress-fill');
const progressText = document.getElementById('progress-text');
const affirmationText = document.getElementById('affirmation-text');
const newAffirmationBtn = document.getElementById('new-affirmation-btn');

// Motivational quotes and affirmations
const motivationalQuotes = [
    "Discipline is the bridge between goals and accomplishment.",
    "Small daily improvements lead to stunning results.",
    "Your routine is the foundation of your success.",
    "Consistency is what transforms average into excellence.",
    "The secret of your future is hidden in your daily routine.",
    "Success is the sum of small efforts repeated daily.",
    "You don't have to be great to start, but you have to start to be great."
];

const dailyAffirmations = [
    "I am in control of my day and my life.",
    "Every task I complete brings me closer to my goals.",
    "I have the power to create positive change in my life.",
    "My discipline is stronger than my excuses.",
    "I am focused, productive, and motivated today.",
    "I honor my commitments to myself.",
    "Each day I grow stronger and more capable."
];

// Initialize with random quote and affirmation
document.querySelector('.motivational-quote').textContent = 
    motivationalQuotes[Math.floor(Math.random() * motivationalQuotes.length)];
affirmationText.textContent = 
    dailyAffirmations[Math.floor(Math.random() * dailyAffirmations.length)];

// Update time and date
function updateDateTime() {
    const now = new Date();
    
    // Format time (HH:MM:SS AM/PM)
    const timeOptions = { hour: '2-digit', minute: '2-digit', second: '2-digit' };
    currentTime.textContent = now.toLocaleTimeString(undefined, timeOptions);
    
    // Format date (Weekday, Month Day, Year)
    const dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    currentDate.textContent = now.toLocaleDateString(undefined, dateOptions);
}

// Update time every second
setInterval(updateDateTime, 1000);
updateDateTime(); // Initial call

// Add task function
function addTask() {
    const taskText = taskInput.value.trim();
    const timeOfDay = timeSelect.value.split(' ')[0]; // Get just the value part
    
    if (taskText) {
        const taskList = document.querySelector(`#${timeOfDay}-tasks .task-list`);
        
        const taskItem = document.createElement('li');
        taskItem.className = 'task-item';
        taskItem.innerHTML = `
            <span class="task-text">${taskText}</span>
            <div class="task-actions">
                <button class="complete-btn" title="Complete"><i class="fas fa-check"></i></button>
                <button class="edit-btn" title="Edit"><i class="fas fa-edit"></i></button>
                <button class="delete-btn" title="Delete"><i class="fas fa-trash"></i></button>
            </div>
        `;
        
        // Add animation for new task
        taskItem.style.animation = 'fadeIn 0.5s ease-out';
        taskList.appendChild(taskItem);
        taskInput.value = '';
        
        // Save to localStorage
        saveTasks();
        // Update progress
        updateProgress();
        
        // Add motivational effect
        if (taskList.children.length === 1) {
            taskList.parentElement.style.animation = 'pulse 0.5s';
            setTimeout(() => {
                taskList.parentElement.style.animation = '';
            }, 500);
        }
    }
}

// Update progress tracker
function updateProgress() {
    const totalTasks = document.querySelectorAll('.task-item').length;
    const completedTasks = document.querySelectorAll('.task-item.completed').length;
    
    if (totalTasks > 0) {
        const progressPercent = Math.round((completedTasks / totalTasks) * 100);
        progressFill.style.width = `${progressPercent}%`;
        progressText.textContent = `${progressPercent}% Complete`;
        
        // Change color based on progress
        if (progressPercent < 30) {
            progressFill.style.background = 'linear-gradient(90deg, #f94144, #f8961e)';
        } else if (progressPercent < 70) {
            progressFill.style.background = 'linear-gradient(90deg, #f8961e, #f9c74f)';
        } else {
            progressFill.style.background = 'linear-gradient(90deg, #4cc9f0, #4ad66d)';
        }
    } else {
        progressFill.style.width = '0%';
        progressText.textContent = '0% Complete';
    }
}

// Handle task actions (complete, edit, delete)
function handleTaskActions(e) {
    const target = e.target.closest('button');
    if (!target) return;
    
    const taskItem = e.target.closest('.task-item');
    
    if (target.classList.contains('complete-btn')) {
        taskItem.classList.toggle('completed');
        // Add celebration effect for completing tasks
        if (taskItem.classList.contains('completed')) {
            taskItem.style.transform = 'scale(1.05)';
            setTimeout(() => {
                taskItem.style.transform = '';
            }, 300);
        }
    } 
    else if (target.classList.contains('delete-btn')) {
        // Add delete animation
        taskItem.style.animation = 'fadeIn 0.3s reverse';
        setTimeout(() => {
            taskItem.remove();
            saveTasks();
            updateProgress();
        }, 300);
        return;
    } 
    else if (target.classList.contains('edit-btn')) {
        const taskText = taskItem.querySelector('.task-text');
        const newText = prompt('Edit your task:', taskText.textContent);
        if (newText !== null) {
            taskText.textContent = newText;
        }
    }
    
    // Save to localStorage
    saveTasks();
    // Update progress
    updateProgress();
}

// Save tasks to localStorage
function saveTasks() {
    const tasks = {};
    const sections = ['morning', 'afternoon', 'evening', 'night'];
    
    sections.forEach(section => {
        const taskElements = document.querySelectorAll(`#${section}-tasks .task-item`);
        tasks[section] = Array.from(taskElements).map(task => ({
            text: task.querySelector('.task-text').textContent,
            completed: task.classList.contains('completed')
        }));
    });
    
    localStorage.setItem('dailyRoutineTasks', JSON.stringify(tasks));
}

// Load tasks from localStorage
function loadTasks() {
    const savedTasks = localStorage.getItem('dailyRoutineTasks');
    if (savedTasks) {
        const tasks = JSON.parse(savedTasks);
        
        for (const section in tasks) {
            const taskList = document.querySelector(`#${section}-tasks .task-list`);
            
            tasks[section].forEach(task => {
                const taskItem = document.createElement('li');
                taskItem.className = `task-item ${task.completed ? 'completed' : ''}`;
                taskItem.innerHTML = `
                    <span class="task-text">${task.text}</span>
                    <div class="task-actions">
                        <button class="complete-btn" title="Complete"><i class="fas fa-check"></i></button>
                        <button class="edit-btn" title="Edit"><i class="fas fa-edit"></i></button>
                        <button class="delete-btn" title="Delete"><i class="fas fa-trash"></i></button>
                    </div>
                `;
                taskList.appendChild(taskItem);
            });
        }
        
        // Update progress after loading
        updateProgress();
    }
}

// Generate new random affirmation
function newAffirmation() {
    const currentAffirmation = affirmationText.textContent;
    let newAffirmation;
    
    // Ensure we get a different affirmation
    do {
        newAffirmation = dailyAffirmations[Math.floor(Math.random() * dailyAffirmations.length)];
    } while (newAffirmation === currentAffirmation && dailyAffirmations.length > 1);
    
    // Add transition effect
    affirmationText.style.animation = 'fadeIn 0.5s ease-out';
    affirmationText.textContent = newAffirmation;
    
    // Reset animation after it completes
    setTimeout(() => {
        affirmationText.style.animation = '';
    }, 500);
}

// Event Listeners
addBtn.addEventListener('click', addTask);
taskInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') addTask();
});

document.querySelectorAll('.routine-section').forEach(section => {
    section.addEventListener('click', handleTaskActions);
});

newAffirmationBtn.addEventListener('click', newAffirmation);

// Initialize the app
loadTasks();

// Focus the input field on page load
window.addEventListener('load', () => {
    taskInput.focus();
});